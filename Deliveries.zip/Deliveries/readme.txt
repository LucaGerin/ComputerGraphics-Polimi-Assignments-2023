Before uploading the file, do the following


Assignment 1: 2D primitives - Tangram

[X] - copy file "triangles.hpp" into folder "A01" 



Assignment 02: Basic trasform - Dog puzzle

[X] - copy file "transforms.hpp" into folder "A02" 



Assignment 03: Advanced trasform - Owl puzzle

[X] - copy file "transforms.hpp" into folder "A03" 



Assignment 04: Parallel projection - Q'Bert

[X] - copy file "projection.hpp" into folder "A04" 



Assignment 05: Perspectove projection - Dungeon

[X] - copy file "projection.hpp" into folder "A05" 



Assignment 06: World and view matrices - Escape room

[X] - copy file "WorldView.hpp" into folder "A06" 



Assignment 07: Third person controller - Among us character runs on Ultima V map

[X] - copy file "Logic.hpp" into folder "A07" 



Assignment 08: Simple mesh creation - Random Maz

[X] - copy file "mazeGen.hpp" into folder "A08" 


Assignment 09: Compile the shaders
Here you have nothing to do, since it will not be evaluated. This assignment was similar to assignment 00, and its purpose was only let you experiment with the shader compiler


Assignment 10: Simple vertex and fragment shader definitions - Function representation

[X] - copy file "shaders/PhongShader.vert" into folder "A10" 
[X] - copy file "shaders/PhongShader.frag" into folder "A10" 



Assignment 11: Light models - Street, room and dungeon

[X] - copy file "shaders/BlinnShader1.frag" into folder "A11" 
[X] - copy file "shaders/BlinnShader2.frag" into folder "A11" 
[X] - copy file "shaders/BlinnShader3.frag" into folder "A11" 



Assignment 12: BRDF models - Spheres and Pool room

[X] - copy file "shaders/BlinnNormMapShader.frag" into folder "A12" 
[X] - copy file "shaders/GGXNormMapShader.frag" into folder "A12" 
[X] - copy file "shaders/OrenNayarShader.frag" into folder "A12" 
[X] - copy file "shaders/PhongShader.frag" into folder "A12" 



Assignment 13: Ambient Light models - Sphere and Night street view

[X] - copy file "shaders/BlinnShader.frag" into folder "A13" 



Assignment 14: Smooth shading - Cube, surface and cylinder

[X] - copy file "primGen.hpp" into folder "A14" 



Assignment 15: UV coordinates - Toy building blocks' box and Mars

[X] - copy file "primGen.hpp" into folder "A15" 



Assignment 16: Vulkan rendering - Complete slot machine game

[X] - copy file "A16.cpp" into folder "A16" 



At the end, if you list the file in all the subfolder, you should have the following structure:

A01/triangles.hpp
A02/transforms.hpp
A03/transforms.hpp
A04/projection.hpp
A05/projection.hpp
A06/WorldView.hpp
A07/Logic.hpp
A08/mazeGen.hpp
A10/PhongShader.frag
A10/PhongShader.vert
A11/BlinnShader1.frag
A11/BlinnShader2.frag
A11/BlinnShader3.frag
A12/BlinnNormMapShader.frag
A12/GGXNormMapShader.frag
A12/OrenNayarShader.frag 
A12/PhongShader.frag
A13/BlinnShader.frag
A14/primGen.hpp
A15/primGen.hpp
A16/A16.cpp

Please also fill file "done.txt" to specify which assignments you have done and which not.